 <div class="span4 well">
 	This is the sidebar menu that was loaded as a section.
 	<br/><br/><br/>
 </div>